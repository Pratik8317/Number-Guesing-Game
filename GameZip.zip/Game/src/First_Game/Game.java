package First_Game;

import java.util.Scanner;

public class Game {
	
	
	public static void main(String[] args) {
		
		int num= (int) (Math.random()*100);
		
		Scanner sc=new Scanner(System.in);
		int usernumber=0;
		do 
		{	
			System.out.println("Guess My Number (0 to 100): ");
			usernumber=sc.nextInt();
			
			if(usernumber==num) 
			{
				System.err.println("You'r Great...! My Number is "+num);
				break;
			}
			else if(usernumber > num)
			{
				System.out.println("Your Number Is Greater Than My Number.");
			}
			else
			{
				System.out.println("Your Number Is To Small.");
			}
		}while(usernumber >= 0);

	}
}
